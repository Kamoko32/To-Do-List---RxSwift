//
//  Task.swift
//  GoodList
//
//  Created by Kamil Gucik on 18/05/2020.
//  Copyright © 2020 Kamil Gucik. All rights reserved.
//

import Foundation
enum Priority: Int {
    case high
    case medium
    case low
}

struct Task {
    let title: String
    let priority: Priority
}
