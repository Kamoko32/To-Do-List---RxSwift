//
//  AddTaskViewController.swift
//  GoodList
//
//  Created by Kamil Gucik on 18/05/2020.
//  Copyright © 2020 Kamil Gucik. All rights reserved.
//

import Foundation
import UIKit
import RxSwift

class AddTaskViewController: UIViewController {
    
    let disposedBag = DisposeBag()
    
    private let taskSubject = PublishSubject<Task>()
    
    var taskSubjectObservable: Observable<Task> {
        return taskSubject.asObservable()
    }
    
    @IBOutlet weak var priority: UISegmentedControl!
    @IBOutlet weak var taskTitleTextField: UITextField!
    
    @IBAction func save() {
        
        guard let priority = Priority(rawValue: self.priority.selectedSegmentIndex), let textTitle = self.taskTitleTextField.text else {
            return print("Segment or text error")
        }
        
        let taskObject = Task(title: textTitle, priority: priority)
        
        taskSubject.onNext(taskObject)
        
        self.dismiss(animated: true, completion: nil)
        
    }
}
