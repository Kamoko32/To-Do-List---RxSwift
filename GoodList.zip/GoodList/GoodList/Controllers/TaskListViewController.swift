//
//  taskListViewController.swift
//  GoodList
//
//  Created by Kamil Gucik on 18/05/2020.
//  Copyright © 2020 Kamil Gucik. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa

class TaskListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let disposedBag = DisposeBag()
    
    private var tasks = BehaviorRelay<[Task]>(value: [])
    
    private var filteredTasks = [Task]()
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.filteredTasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskTableViewCell",for: indexPath)
        cell.textLabel?.text = self.filteredTasks[indexPath.row].title
        return cell
    }
    
    
    
 
    @IBOutlet weak var prioritySegmentedControl: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard let navC = segue.destination as? UINavigationController,
            let addTVC = navC.viewControllers.first as? AddTaskViewController else {
            fatalError("Culdnt find AddTVC")
        }
        
        addTVC.taskSubjectObservable.subscribe(onNext: {[unowned self] task in
            
            let priority = Priority(rawValue: self.prioritySegmentedControl.selectedSegmentIndex - 1)
            
            var existingTask = self.tasks.value
            existingTask.append(task)
            self.tasks.accept(existingTask)
            
            self.filterTask(by: priority)
            
            
        }).disposed(by: disposedBag)
        
    }
    
    private func updateTableView() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    @IBAction func priorityValueChange(segmentControl: UISegmentedControl) {
        
        let priority = Priority(rawValue: prioritySegmentedControl.selectedSegmentIndex - 1)
        filterTask(by: priority)
    }
    
    private func filterTask(by priority: Priority?) {
        
        if priority == nil {
            self.filteredTasks = self.tasks.value
            self.updateTableView()
        } else {
            
            self.tasks.map { tasks in
                return tasks.filter { $0.priority == priority! }
            }.subscribe(onNext: {[weak self] tasks in
                self?.filteredTasks = tasks
                self?.updateTableView()
                }).disposed(by: disposedBag)
        }
    }
}
